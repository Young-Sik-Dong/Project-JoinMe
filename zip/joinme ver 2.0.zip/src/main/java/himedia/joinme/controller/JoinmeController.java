package himedia.joinme.controller;

public class JoinmeController {

}
